A updated version of the previous Acksent demo app, this version does not require the usage of Firebase.
