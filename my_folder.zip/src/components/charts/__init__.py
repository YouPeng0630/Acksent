from src.components.charts.combine_plot import create_combined_plot1
from src.components.charts.test_plot import generate_progress_chart
from src.components.charts.dount_chart import make_donut
from src.components.charts.progress_plot import create_dashboard_figure