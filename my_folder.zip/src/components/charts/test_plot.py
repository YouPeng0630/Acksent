import streamlit as st
import plotly.graph_objects as go
import count_progress as cp

def generate_progress_chart():
    # 定义数据
    groups = {
        'Group 1': [int(cp.progress_counts.get('record_Sophie.csv', 0)), int(cp.progress_counts.get('record_Manika.csv', 0))],
        'Group 2': [int(cp.progress_counts.get('record_Jigyashu.csv', 0)), int(cp.progress_counts.get('record_Nikhil.csv', 0))],
        'Group 3': [int(cp.progress_counts.get('record_Manali.csv', 0)), int(cp.progress_counts.get('record_Satyam.csv', 0))],
        'Group 4': [int(cp.progress_counts.get('record_Amreentaj.csv', 0)), int(cp.progress_counts.get('record_Haley.csv', 0))],
        'Group 5': [int(cp.progress_counts.get('record_Nicholas.csv', 0)), int(cp.progress_counts.get('record_Atharv.csv', 0))],
        'Group 6': [int(cp.progress_counts.get('record_Tina.csv', 0)), int(cp.progress_counts.get('record_Shariq.csv', 0))]
    }

    names = [
        ('Sophie', 'Manika'),
        ('Jigyashu', 'Nikhil'),
        ('Manali', 'Satyam'),
        ('Amreentaj', 'Haley'),
        ('Nicholas', 'Atharv'),
        ('Tina', 'Shariq')
    ]

    # 提取数据
    labels = list(groups.keys())
    data1 = [-values[0] for values in groups.values()]  # 负数使其向左延伸
    data2 = [values[1] for values in groups.values()]

    # 创建 Plotly 图表
    fig = go.Figure()

    # 添加第一组数据
    fig.add_trace(go.Bar(
        y=labels,
        x=data1,
        name='First Member',
        orientation='h',
        marker=dict(color='skyblue'),
        text=[name[0] for name in names],  # 只显示名字
        textposition='outside',  # 在柱状图外显示文本
        insidetextanchor='start'
    ))

    # 添加第二组数据
    fig.add_trace(go.Bar(
        y=labels,
        x=data2,
        name='Second Member',
        orientation='h',
        marker=dict(color='salmon'),
        text=[name[1] for name in names],  # 只显示名字
        textposition='outside',  # 在柱状图外显示文本
        insidetextanchor='start'
    ))

    # 设置标签和标题
    fig.update_layout(
        barmode='relative',
        title='Number Relations in Each Group',
        xaxis_title='',
        yaxis_title='Groups',
        template='plotly_white',
        xaxis=dict(showticklabels=False, showgrid=True, gridwidth=0.5, gridcolor='LightGrey', zeroline=True, zerolinewidth=1, zerolinecolor='Black'),
        width=1000,  # 调整图表宽度
        margin=dict(l=20, r=30, t=40, b=20),  # 设置边距
        showlegend=False  # 隐藏图例
    )

    return fig

# 调用函数并显示图表
if __name__ == '__main__':
    fig = generate_progress_chart()
    st.plotly_chart(fig, config={'displayModeBar': False})  # 隐藏模式栏
